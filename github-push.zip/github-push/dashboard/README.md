# VulnIntel Dashboard — single-file demo console

`index.html` is the entire frontend. No build step, no dependencies, no server needed.
It talks to the VulnIntel API on Render (CORS is open) and auto-detects the API base
(changeable in the header, remembered in localStorage).

**Status (2026-10-24): ALL FOUR PANELS LIVE against production — including the Self-Learning Loop.**

## Run it (pick one)

1. **Local:** double-click `index.html` (works from `file://` — CORS on the API is verified open).
2. **Local server:** `python3 -m http.server 8899` in this folder → http://localhost:8899
3. **GitHub Pages (recommended for demo day):** enable Pages (Settings → Pages →
   Deploy from a branch → `main` → `/ (root)`) → the dashboard is served at
   `https://srushtyrai7.github.io/vul-intel-git/dashboard/`

## The panels

| Panel | Endpoint | Demo story |
|---|---|---|
| Repo Scan | `POST /scan-repo` | OSV.dev → CVSS → live EPSS → Real Risk. Amber row #1 = fix first; violet note on the CVSS-10 row = the whole product thesis ("CVSS 10 but 1.44% exploited → ranked 10") |
| Ask | `POST /ask` | Plain-English priority answer over pgvector RAG |
| Assets | `GET/POST /assets` | Criticality feeds the formula; add one live and rescan to show risk scaling |
| Feedback buttons | `POST /decisions` | ✓ patched / ✕ dismiss per finding — write-side of the learning loop |
| Self-Learning Loop | `GET /decisions` + `GET /insights` | LIVE. Auto-detects on page load; shows accepted vs dismissed sets + full decision history |

## The self-learning loop (LIVE — proven 2026-10-24)

The loop is closed end-to-end and verified on production:

1. Analyst clicks ✓/✕ on a scan finding → `POST /decisions` records it
2. `GET /decisions` / `GET /insights` expose the feedback (patched vs dismissed sets)
3. `POST /ask` **demotes every dismissed CVE by exactly 50% and re-ranks** — proven live:
   baseline #1 = CVE-2026-76795 @ 0.04 → dismiss → identical re-ask → @ 0.02,
   `demoted_by_feedback: true`, `feedback_applied: true`

QA: `test_selflearning.py` = 5/5 PASS. Dashboard screenshot: `selflearning_live.png`.

## 30-second demo script for the loop

Ask a question → note the #1 CVE → click ✕ on that row in the Scan panel →
re-ask the **same** question → the risk halves and rankings shuffle. Deterministic, honest, no LLM involved.
